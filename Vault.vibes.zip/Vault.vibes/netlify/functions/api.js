// ===== VIBEVAULT BACKEND API =====
// Netlify Function: netlify/functions/api.js
// Stack Ultimate — All API keys hardcoded per project preference

const { neon } = require('@neondatabase/serverless');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const https = require('https');

const NEON_DB_URL = '';
// ===== HARDCODED API KEYS =====
const JWT_SECRET = 'vibevault_jwt_secret_stack_ultimate_2025_change_in_production';
const PAYSTACK_SECRET_KEY = ''; // 🔑 Replace with your secret key
const PAYSTACK_BASE = 'https://api.paystack.co';

// ===== SPLIT PAYMENT =====
// Go to Paystack Dashboard → Settings → Split Payment → Create Split
// Add yourself + your partner's subaccount, set percentages, copy the split code here.
const PAYSTACK_SPLIT_CODE = ''; // 🔑 e.g. 'SPL_X06o98Jcl5'

// DB Client
const sql = neon(NEON_DB_URL);

// ===== DB INIT (run once) =====
async function initDB() {
  await sql`
    CREATE TABLE IF NOT EXISTS users (
      id SERIAL PRIMARY KEY,
      email VARCHAR(255) UNIQUE NOT NULL,
      password_hash VARCHAR(255) NOT NULL,
      username VARCHAR(100) UNIQUE NOT NULL,
      full_name VARCHAR(255),
      bio TEXT,
      avatar_url TEXT,
      cover_url TEXT,
      artist_type VARCHAR(50) DEFAULT 'music',
      is_verified BOOLEAN DEFAULT false,
      subscription_tier VARCHAR(20) DEFAULT 'free',
      subscription_expires_at TIMESTAMP,
      follower_count INTEGER DEFAULT 0,
      following_count INTEGER DEFAULT 0,
      created_at TIMESTAMP DEFAULT NOW()
    )
  `;

  await sql`
    CREATE TABLE IF NOT EXISTS posts (
      id SERIAL PRIMARY KEY,
      user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
      type VARCHAR(20) DEFAULT 'question',
      parent_id INTEGER REFERENCES posts(id) ON DELETE CASCADE,
      space VARCHAR(50) DEFAULT 'music',
      title TEXT,
      body TEXT,
      image_url TEXT,
      upvotes INTEGER DEFAULT 0,
      view_count INTEGER DEFAULT 0,
      answer_count INTEGER DEFAULT 0,
      is_featured BOOLEAN DEFAULT false,
      created_at TIMESTAMP DEFAULT NOW(),
      updated_at TIMESTAMP DEFAULT NOW()
    )
  `;

  await sql`
    CREATE TABLE IF NOT EXISTS votes (
      id SERIAL PRIMARY KEY,
      user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
      post_id INTEGER REFERENCES posts(id) ON DELETE CASCADE,
      vote_type VARCHAR(10),
      created_at TIMESTAMP DEFAULT NOW(),
      UNIQUE(user_id, post_id)
    )
  `;

  await sql`
    CREATE TABLE IF NOT EXISTS follows (
      id SERIAL PRIMARY KEY,
      follower_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
      following_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
      created_at TIMESTAMP DEFAULT NOW(),
      UNIQUE(follower_id, following_id)
    )
  `;

  await sql`
    CREATE TABLE IF NOT EXISTS subscriptions (
      id SERIAL PRIMARY KEY,
      user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
      tier VARCHAR(20) NOT NULL,
      paystack_reference VARCHAR(255) UNIQUE,
      amount INTEGER,
      status VARCHAR(20) DEFAULT 'active',
      starts_at TIMESTAMP DEFAULT NOW(),
      expires_at TIMESTAMP,
      created_at TIMESTAMP DEFAULT NOW()
    )
  `;
}

// ===== HELPERS =====
function response(statusCode, body) {
  return {
    statusCode,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS'
    },
    body: JSON.stringify(body)
  };
}

function parseBody(event) {
  try { return JSON.parse(event.body || '{}'); } catch { return {}; }
}

function getAuth(event) {
  const auth = event.headers.authorization || event.headers.Authorization || '';
  if (!auth.startsWith('Bearer ')) return null;
  try {
    return jwt.verify(auth.slice(7), JWT_SECRET);
  } catch { return null; }
}

function getPath(event) {
  const raw = event.path || '';
  const stripped = raw.replace(/^\/api/, '').replace(/^\/.netlify\/functions\/api/, '');
  return stripped || '/';
}

async function paystackRequest(method, path, body = null) {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'api.paystack.co',
      path,
      method,
      headers: {
        'Authorization': `Bearer ${PAYSTACK_SECRET_KEY}`,
        'Content-Type': 'application/json'
      }
    };
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch { reject(new Error('Invalid JSON from Paystack')); }
      });
    });
    req.on('error', reject);
    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

// ===== MAIN HANDLER =====
exports.handler = async (event) => {
  // CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return response(200, {});
  }

  const path = getPath(event);
  const method = event.httpMethod;

  // Init DB on cold start
  try { await initDB(); } catch (e) { console.error('DB Init error:', e.message); }

  try {
    // ===== AUTH ROUTES =====
    if (path === '/auth/register' && method === 'POST') {
      const { full_name, username, email, password, artist_type } = parseBody(event);

      if (!email || !password || !username) {
        return response(400, { error: 'Email, username, and password are required.' });
      }
      if (password.length < 8) {
        return response(400, { error: 'Password must be at least 8 characters.' });
      }

      // Check existing user
      const existing = await sql`SELECT id FROM users WHERE email = ${email} OR username = ${username}`;
      if (existing.length > 0) {
        return response(409, { error: 'Email or username already taken.' });
      }

      const password_hash = await bcrypt.hash(password, 12);
      const [user] = await sql`
        INSERT INTO users (email, password_hash, username, full_name, artist_type)
        VALUES (${email}, ${password_hash}, ${username.toLowerCase()}, ${full_name || username}, ${artist_type || 'music'})
        RETURNING id, email, username, full_name, artist_type, subscription_tier, avatar_url, bio, created_at
      `;

      const token = jwt.sign({ userId: user.id, email: user.email }, JWT_SECRET, { expiresIn: '30d' });
      return response(201, { token, user });
    }

    if (path === '/auth/login' && method === 'POST') {
      const { email, password } = parseBody(event);
      if (!email || !password) {
        return response(400, { error: 'Email and password are required.' });
      }

      const [user] = await sql`SELECT * FROM users WHERE email = ${email}`;
      if (!user) return response(401, { error: 'Invalid email or password.' });

      const valid = await bcrypt.compare(password, user.password_hash);
      if (!valid) return response(401, { error: 'Invalid email or password.' });

      // Return user without password hash
      delete user.password_hash;
      const token = jwt.sign({ userId: user.id, email: user.email }, JWT_SECRET, { expiresIn: '30d' });
      return response(200, { token, user });
    }

    // ===== POSTS ROUTES =====
    if (path === '/posts' && method === 'GET') {
      const params = event.queryStringParameters || {};
      const space = params.space;
      const limit = parseInt(params.limit || '20');
      const offset = parseInt(params.offset || '0');
      const userId = params.userId;

      let posts;
      if (space) {
        posts = await sql`
          SELECT p.*, u.full_name, u.username, u.avatar_url, u.subscription_tier, u.artist_type
          FROM posts p JOIN users u ON p.user_id = u.id
          WHERE p.type = 'question' AND p.space = ${space}
          ORDER BY p.created_at DESC LIMIT ${limit} OFFSET ${offset}
        `;
      } else if (userId) {
        posts = await sql`
          SELECT p.*, u.full_name, u.username, u.avatar_url, u.subscription_tier, u.artist_type
          FROM posts p JOIN users u ON p.user_id = u.id
          WHERE p.user_id = ${userId} AND p.type = 'question'
          ORDER BY p.created_at DESC LIMIT ${limit} OFFSET ${offset}
        `;
      } else {
        posts = await sql`
          SELECT p.*, u.full_name, u.username, u.avatar_url, u.subscription_tier, u.artist_type
          FROM posts p JOIN users u ON p.user_id = u.id
          WHERE p.type = 'question'
          ORDER BY p.upvotes DESC, p.created_at DESC LIMIT ${limit} OFFSET ${offset}
        `;
      }
      return response(200, { posts });
    }

    if (path === '/posts' && method === 'POST') {
      const auth = getAuth(event);
      if (!auth) return response(401, { error: 'Authentication required.' });

      const { title, body, space, image_url } = parseBody(event);
      if (!title || title.trim().length < 10) {
        return response(400, { error: 'Title must be at least 10 characters.' });
      }

      // Free plan: check daily question limit
      const [user] = await sql`SELECT subscription_tier FROM users WHERE id = ${auth.userId}`;
      if (user?.subscription_tier === 'free') {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const [count] = await sql`
          SELECT COUNT(*) as cnt FROM posts
          WHERE user_id = ${auth.userId} AND type = 'question' AND created_at > ${today.toISOString()}
        `;
        if (parseInt(count.cnt) >= 5) {
          return response(429, { error: 'Free plan limit: 5 questions per day. Upgrade for unlimited questions.' });
        }
      }

      const [post] = await sql`
        INSERT INTO posts (user_id, type, title, body, space, image_url)
        VALUES (${auth.userId}, 'question', ${title.trim()}, ${body || null}, ${space || 'music'}, ${image_url || null})
        RETURNING *
      `;
      return response(201, { post });
    }

    // Get single post
    const questionMatch = path.match(/^\/posts\/(\d+)$/);
    if (questionMatch && method === 'GET') {
      const postId = questionMatch[1];
      const [post] = await sql`
        SELECT p.*, u.full_name, u.username, u.avatar_url, u.subscription_tier, u.is_verified, u.artist_type
        FROM posts p JOIN users u ON p.user_id = u.id
        WHERE p.id = ${postId}
      `;
      if (!post) return response(404, { error: 'Post not found.' });

      // Increment view count
      await sql`UPDATE posts SET view_count = view_count + 1 WHERE id = ${postId}`;

      // Get answers
      const answers = await sql`
        SELECT p.*, u.full_name, u.username, u.avatar_url, u.subscription_tier, u.is_verified, u.artist_type
        FROM posts p JOIN users u ON p.user_id = u.id
        WHERE p.parent_id = ${postId} AND p.type = 'answer'
        ORDER BY p.upvotes DESC, p.created_at ASC
      `;

      return response(200, { post, answers });
    }

    // Post answers
    const answerMatch = path.match(/^\/posts\/(\d+)\/answers$/);
    if (answerMatch && method === 'POST') {
      const auth = getAuth(event);
      if (!auth) return response(401, { error: 'Authentication required.' });

      const postId = answerMatch[1];
      const { body } = parseBody(event);
      if (!body || body.trim().length < 20) {
        return response(400, { error: 'Answer must be at least 20 characters.' });
      }

      const [answer] = await sql`
        INSERT INTO posts (user_id, type, parent_id, body)
        VALUES (${auth.userId}, 'answer', ${postId}, ${body.trim()})
        RETURNING *
      `;

      // Increment parent answer count
      await sql`UPDATE posts SET answer_count = answer_count + 1 WHERE id = ${postId}`;

      return response(201, { answer });
    }

    // Vote on post
    const voteMatch = path.match(/^\/posts\/(\d+)\/vote$/);
    if (voteMatch && method === 'POST') {
      const auth = getAuth(event);
      if (!auth) return response(401, { error: 'Authentication required.' });

      const postId = voteMatch[1];
      const { type } = parseBody(event);

      if (type === 'remove') {
        await sql`DELETE FROM votes WHERE user_id = ${auth.userId} AND post_id = ${postId}`;
        await sql`UPDATE posts SET upvotes = upvotes - 1 WHERE id = ${postId}`;
      } else {
        const existing = await sql`SELECT id FROM votes WHERE user_id = ${auth.userId} AND post_id = ${postId}`;
        if (existing.length === 0) {
          await sql`INSERT INTO votes (user_id, post_id, vote_type) VALUES (${auth.userId}, ${postId}, 'up')`;
          await sql`UPDATE posts SET upvotes = upvotes + 1 WHERE id = ${postId}`;
        }
      }
      return response(200, { success: true });
    }

    // ===== USER ROUTES =====
    const userMatch = path.match(/^\/users\/(\d+|profile)$/);
    if (userMatch && method === 'GET') {
      const identifier = userMatch[1];
      const auth = getAuth(event);

      let user;
      if (identifier === 'profile' && auth) {
        [user] = await sql`
          SELECT id, email, username, full_name, bio, avatar_url, cover_url, artist_type,
                 is_verified, subscription_tier, follower_count, following_count, created_at
          FROM users WHERE id = ${auth.userId}
        `;
      } else {
        [user] = await sql`
          SELECT id, username, full_name, bio, avatar_url, cover_url, artist_type,
                 is_verified, subscription_tier, follower_count, following_count, created_at
          FROM users WHERE id = ${identifier}
        `;
      }

      if (!user) return response(404, { error: 'User not found.' });
      return response(200, { user });
    }

    if (path === '/users/profile' && method === 'PUT') {
      const auth = getAuth(event);
      if (!auth) return response(401, { error: 'Authentication required.' });

      const { full_name, bio, avatar_url, cover_url, artist_type } = parseBody(event);
      const [user] = await sql`
        UPDATE users
        SET full_name = COALESCE(${full_name || null}, full_name),
            bio = COALESCE(${bio || null}, bio),
            avatar_url = COALESCE(${avatar_url || null}, avatar_url),
            cover_url = COALESCE(${cover_url || null}, cover_url),
            artist_type = COALESCE(${artist_type || null}, artist_type)
        WHERE id = ${auth.userId}
        RETURNING id, email, username, full_name, bio, avatar_url, cover_url, artist_type,
                  is_verified, subscription_tier, follower_count, following_count
      `;
      return response(200, { user });
    }

    // Follow/Unfollow
    const followMatch = path.match(/^\/users\/(\d+)\/follow$/);
    if (followMatch && method === 'POST') {
      const auth = getAuth(event);
      if (!auth) return response(401, { error: 'Authentication required.' });

      const targetId = followMatch[1];
      if (parseInt(targetId) === auth.userId) {
        return response(400, { error: 'Cannot follow yourself.' });
      }

      const existing = await sql`
        SELECT id FROM follows WHERE follower_id = ${auth.userId} AND following_id = ${targetId}
      `;

      if (existing.length > 0) {
        await sql`DELETE FROM follows WHERE follower_id = ${auth.userId} AND following_id = ${targetId}`;
        await sql`UPDATE users SET following_count = following_count - 1 WHERE id = ${auth.userId}`;
        await sql`UPDATE users SET follower_count = follower_count - 1 WHERE id = ${targetId}`;
        return response(200, { following: false });
      } else {
        await sql`INSERT INTO follows (follower_id, following_id) VALUES (${auth.userId}, ${targetId})`;
        await sql`UPDATE users SET following_count = following_count + 1 WHERE id = ${auth.userId}`;
        await sql`UPDATE users SET follower_count = follower_count + 1 WHERE id = ${targetId}`;
        return response(200, { following: true });
      }
    }

    // ===== SUBSCRIPTION ROUTES =====
    if (path === '/subscriptions/initialize' && method === 'POST') {
      const auth = getAuth(event);
      if (!auth) return response(401, { error: 'Authentication required.' });

      const { plan } = parseBody(event);
      const [user] = await sql`SELECT email FROM users WHERE id = ${auth.userId}`;
      if (!user) return response(404, { error: 'User not found.' });

      const amounts = { plus: 249900, pro: 599900 };
      const amount = amounts[plan];
      if (!amount) return response(400, { error: 'Invalid plan.' });

      const paystackRes = await paystackRequest('POST', '/transaction/initialize', {
        email: user.email,
        amount,
        currency: 'NGN',
        split_code: PAYSTACK_SPLIT_CODE,   // ← revenue split applied here
        metadata: { userId: auth.userId, plan }
      });

      if (!paystackRes.status) {
        return response(500, { error: 'Failed to initialize payment.' });
      }

      return response(200, {
        authorization_url: paystackRes.data.authorization_url,
        reference: paystackRes.data.reference
      });
    }

    if (path === '/subscriptions/verify' && method === 'POST') {
      const auth = getAuth(event);
      if (!auth) return response(401, { error: 'Authentication required.' });

      const { reference, plan } = parseBody(event);
      if (!reference) return response(400, { error: 'Reference is required.' });

      // Verify with Paystack
      const verify = await paystackRequest('GET', `/transaction/verify/${reference}`);

      if (!verify.status || verify.data?.status !== 'success') {
        return response(400, { error: 'Payment verification failed.' });
      }

      // Calculate expiry
      const expiresAt = new Date();
      expiresAt.setMonth(expiresAt.getMonth() + 1);

      // Save subscription
      await sql`
        INSERT INTO subscriptions (user_id, tier, paystack_reference, amount, status, expires_at)
        VALUES (${auth.userId}, ${plan}, ${reference}, ${verify.data.amount}, 'active', ${expiresAt.toISOString()})
        ON CONFLICT (paystack_reference) DO NOTHING
      `;

      // Update user tier
      await sql`
        UPDATE users
        SET subscription_tier = ${plan}, subscription_expires_at = ${expiresAt.toISOString()}
        WHERE id = ${auth.userId}
      `;

      return response(200, { success: true, plan, expires_at: expiresAt });
    }

    // ===== AD CAMPAIGNS =====
    if (path === '/ads' && method === 'POST') {
      const { reference, pkg, brand, email, headline, body, image_url, click_url, target_space, amount } = parseBody(event);
      if (!reference || !brand || !headline) {
        return response(400, { error: 'Missing required ad fields.' });
      }
      // Create ads table if first time
      await sql`
        CREATE TABLE IF NOT EXISTS ad_campaigns (
          id SERIAL PRIMARY KEY,
          paystack_reference VARCHAR(255) UNIQUE,
          pkg VARCHAR(50),
          brand VARCHAR(255),
          advertiser_email VARCHAR(255),
          headline VARCHAR(60),
          body_text VARCHAR(120),
          image_url TEXT,
          click_url TEXT,
          target_space VARCHAR(50) DEFAULT 'all',
          amount INTEGER,
          status VARCHAR(20) DEFAULT 'pending_review',
          starts_at TIMESTAMP,
          ends_at TIMESTAMP,
          impressions INTEGER DEFAULT 0,
          clicks INTEGER DEFAULT 0,
          created_at TIMESTAMP DEFAULT NOW()
        )
      `;
      // Verify payment with Paystack before saving
      const verify = await paystackRequest('GET', `/transaction/verify/${reference}`);
      if (!verify.status || verify.data?.status !== 'success') {
        return response(400, { error: 'Payment not confirmed by Paystack.' });
      }
      const startsAt = new Date();
      const endsAt = new Date();
      endsAt.setDate(endsAt.getDate() + 30);
      await sql`
        INSERT INTO ad_campaigns
          (paystack_reference, pkg, brand, advertiser_email, headline, body_text, image_url, click_url, target_space, amount, status, starts_at, ends_at)
        VALUES
          (${reference}, ${pkg}, ${brand}, ${email}, ${headline}, ${body||''}, ${image_url||''}, ${click_url||''}, ${target_space||'all'}, ${verify.data.amount}, 'pending_review', ${startsAt.toISOString()}, ${endsAt.toISOString()})
        ON CONFLICT (paystack_reference) DO NOTHING
      `;
      return response(200, { success: true, message: 'Ad saved. Will go live within 24h after review.' });
    }

    // ===== CONTACT FORM =====
    if (path === '/contact' && method === 'POST') {
      const { name, email, subject, message } = parseBody(event);
      if (!name || !email || !subject || !message) {
        return response(400, { error: 'All fields are required.' });
      }
      // Save to DB so you can review messages in your Neon dashboard
      await sql`
        CREATE TABLE IF NOT EXISTS contact_messages (
          id SERIAL PRIMARY KEY,
          name VARCHAR(255),
          email VARCHAR(255),
          subject VARCHAR(100),
          message TEXT,
          created_at TIMESTAMP DEFAULT NOW()
        )
      `;
      await sql`
        INSERT INTO contact_messages (name, email, subject, message)
        VALUES (${name}, ${email}, ${subject}, ${message})
      `;
      return response(200, { success: true });
    }

    // ===== SEARCH =====
    if (path === '/search' && method === 'GET') {
      const q = event.queryStringParameters?.q || '';
      if (!q || q.length < 2) return response(400, { error: 'Query too short.' });

      const posts = await sql`
        SELECT p.id, p.title, p.space, p.upvotes, p.answer_count, p.created_at,
               u.full_name, u.username, u.avatar_url
        FROM posts p JOIN users u ON p.user_id = u.id
        WHERE p.type = 'question' AND (
          p.title ILIKE ${'%' + q + '%'} OR p.body ILIKE ${'%' + q + '%'}
        )
        ORDER BY p.upvotes DESC LIMIT 20
      `;

      const users = await sql`
        SELECT id, username, full_name, avatar_url, artist_type, follower_count
        FROM users
        WHERE username ILIKE ${'%' + q + '%'} OR full_name ILIKE ${'%' + q + '%'}
        LIMIT 10
      `;

      return response(200, { posts, users });
    }

    // ===== TRENDING =====
    if (path === '/trending' && method === 'GET') {
      const posts = await sql`
        SELECT p.id, p.title, p.space, p.upvotes, p.answer_count, p.view_count,
               u.full_name, u.username, u.avatar_url
        FROM posts p JOIN users u ON p.user_id = u.id
        WHERE p.type = 'question' AND p.created_at > NOW() - INTERVAL '7 days'
        ORDER BY (p.upvotes * 2 + p.answer_count * 3 + p.view_count) DESC
        LIMIT 10
      `;
      return response(200, { posts });
    }

    // 404
    return response(404, { error: `Route not found: ${method} ${path}` });

  } catch (error) {
    console.error('API Error:', error);
    return response(500, { error: 'Internal server error.', details: error.message });
  }
};
