# VibeVault — Final Build
### Where Artists Collide | Stack Ultimate 🇳🇬

## 🔧 Before You Deploy — 3 Replacements

### 1. Neon DB
In `netlify/functions/api.js` line 10:
```
const NEON_DB_URL = 'postgresql://...YOUR NEON URL...'
```

### 2. Paystack Keys
In `index.html`:
```js
const PAYSTACK_KEY='pk_live_YOUR_KEY';
```
In `netlify/functions/api.js`:
```js
const PAYSTACK_SECRET_KEY = 'sk_live_YOUR_KEY';
```

### 3. Google AdSense Publisher ID
In `index.html` — replace ALL 5 occurrences of:
```
ca-pub-XXXXXXXXXXXXXXXXX  →  your real publisher ID
XXXXXXXXXX               →  your real ad slot ID per placement
```
AdSense placements:
- Feed right sidebar (300×250)
- Feed right sidebar second slot (300×280)
- Question detail sidebar (300×250)
- Space detail aside (300×250)
- Following page sidebar (300×250)
- In-feed fluid ad (every 4 posts, free users only)

## 🚀 Deploy
```bash
npm install
netlify deploy --prod --dir .
```
Or drag the folder onto app.netlify.com

## 💰 Revenue Streams
| Source | Who sees it |
|--------|-------------|
| AdSense sidebar ads | Free users only |
| In-feed AdSense | Free users, every 4 posts |
| VibeVault+ ₦2,499/mo | Removes all ads |
| VibeVault Pro ₦5,999/mo | Removes ads + verified badge + portfolio |

